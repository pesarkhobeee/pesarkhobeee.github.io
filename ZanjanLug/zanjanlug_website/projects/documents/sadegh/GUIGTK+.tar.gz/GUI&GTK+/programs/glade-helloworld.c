#include <gtk/gtk.h>
#include <glade/glade.h>

/* This is a callback function. The data arguments are ignored
 * in this example. More on callbacks below. */
static void hello( GtkWidget *widget,
                   gpointer   data )
{
    g_print ("Hello World\n");
}

static gboolean delete_event( GtkWidget *widget,
                              GdkEvent  *event,
                              gpointer   data )
{
    /* If you return FALSE in the "delete_event" signal handler,
     * GTK will emit the "destroy" signal. Returning TRUE means
     * you don't want the window to be destroyed.
     * This is useful for popping up 'are you sure you want to quit?'
     * type dialogs. */

    g_print ("delete event occurred\n");

    /* Change TRUE to FALSE and the main window will be destroyed with
     * a "delete_event". */

    return TRUE;
}

/* Another callback */
static void destroy( GtkWidget *widget,
                     gpointer   data )
{
    gtk_main_quit ();
}

int main( int   argc,
          char *argv[] )
{
    /* GtkWidget is the storage type for widgets */
    GtkWidget *window;
    GtkWidget *button;
    
    /* GladeXML is the storage type for glade xml file */
    GladeXML *glade_xml_file;
    
    /* This is called in all GTK applications. Arguments are parsed
     * from the command line and are returned to the application. */
    gtk_init (&argc, &argv);
    
    /* load the interface */
    glade_xml_file = glade_xml_new("hw.glade", NULL, NULL);
      
    /* Fetch window feature from glade file */
    window = glade_xml_get_widget(glade_xml_file, "window1");
       
    /* Fetch button feature from glade file */
    button = glade_xml_get_widget(glade_xml_file, "button1");
    
    /* Connect signals*/
    glade_xml_signal_connect(glade_xml_file, "delete_event",G_CALLBACK (delete_event));
    glade_xml_signal_connect(glade_xml_file, "destroy",G_CALLBACK (destroy));  
    glade_xml_signal_connect(glade_xml_file, "hello",G_CALLBACK (hello)); 
    
    /* This will cause the window to be destroyed by calling
     * gtk_widget_destroy(window) when "clicked".  Again, the destroy
     * signal could come from here, or the window manager. */
    g_signal_connect_swapped (G_OBJECT (button), "clicked",
			      G_CALLBACK (gtk_widget_destroy),
                              G_OBJECT (window));
    
    gtk_widget_show_all(window);
        
    /* All GTK applications must have a gtk_main(). Control ends here
     * and waits for an event to occur (like a key press or
     * mouse event). */
    gtk_main ();
    
    return 0;
}
