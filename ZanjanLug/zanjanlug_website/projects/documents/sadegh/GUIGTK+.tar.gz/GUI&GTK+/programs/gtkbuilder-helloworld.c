#include <gtk/gtk.h>


/* This is a callback function. The data arguments are ignored
 * in this example. More on callbacks below. */
static void hello( GtkWidget *widget,
                   gpointer   data )
{
    g_print ("Hello World\n");
}

static gboolean delete_event( GtkWidget *widget,
                              GdkEvent  *event,
                              gpointer   data )
{
    /* If you return FALSE in the "delete_event" signal handler,
     * GTK will emit the "destroy" signal. Returning TRUE means
     * you don't want the window to be destroyed.
     * This is useful for popping up 'are you sure you want to quit?'
     * type dialogs. */

    g_print ("delete event occurred\n");

    /* Change TRUE to FALSE and the main window will be destroyed with
     * a "delete_event". */

    return TRUE;
}

/* Another callback */
static void destroy( GtkWidget *widget,
                     gpointer   data )
{
    gtk_main_quit ();
}

int main( int   argc,
          char *argv[] )
{
    /* GtkWidget is the storage type for widgets */
    GtkWidget *window;
    GtkWidget *button;
    
    /* GtkBuilder is the storage type for ui xml file */
    GtkBuilder *uixml;
    
    /* This is called in all GTK applications. Arguments are parsed
     * from the command line and are returned to the application. */
    gtk_init (&argc, &argv);
    
    /* load the interface */
    uixml = gtk_builder_new();
	gtk_builder_add_from_file(uixml, "hw.ui", NULL);
      
    /* Fetch window feature from glade file */
    window = GTK_WIDGET(gtk_builder_get_object (uixml, "window1"));
    /* Connect signals*/
    g_signal_connect(G_OBJECT(window), "delete-event", G_CALLBACK(delete_event), NULL);			
	g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(destroy), NULL);  
	 
    /* Fetch button feature from glade file */
    button = GTK_WIDGET(gtk_builder_get_object (uixml, "button1"));
    /* Connect signals*/
    g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(hello), NULL);	
    

    /* This will cause the window to be destroyed by calling
     * gtk_widget_destroy(window) when "clicked".  Again, the destroy
     * signal could come from here, or the window manager. */
    g_signal_connect_swapped (G_OBJECT (button), "clicked",
			      G_CALLBACK (gtk_widget_destroy),
                              G_OBJECT (window));
    
    gtk_widget_show_all(window);
        
    /* All GTK applications must have a gtk_main(). Control ends here
     * and waits for an event to occur (like a key press or
     * mouse event). */
    gtk_main ();
    
    return 0;
}
