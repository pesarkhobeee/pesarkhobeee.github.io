-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2009 at 09:11 PM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gallery`
--
CREATE DATABASE `gallery` DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci;
USE `gallery`;

-- --------------------------------------------------------

--
-- Table structure for table `gallery_groups`
--

CREATE TABLE IF NOT EXISTS `gallery_groups` (
  `g_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `g_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `g_hidden` tinyint(1) NOT NULL,
  PRIMARY KEY (`g_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `gallery_groups`
--

INSERT INTO `gallery_groups` (`g_id`, `g_name`, `g_hidden`) VALUES
(1, 'Ø¹Ù…ÙˆÙ…ÛŒ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `gallery_img`
--

CREATE TABLE IF NOT EXISTS `gallery_img` (
  `img_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img_url` varchar(400) COLLATE utf8_persian_ci NOT NULL,
  `img_title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `img_alt` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `g_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`img_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `gallery_img`
--

INSERT INTO `gallery_img` (`img_id`, `img_url`, `img_title`, `img_alt`, `g_id`) VALUES
(6, 'Sunset.jpg', 'Sunset', 'Sunset', 1),
(4, 'Winter.jpg', 'Winter', 'Winter', 1),
(10, 'Sunset.jpg', 'Sunset', 'Sunset', 1),
(14, '11111113.JPG', 'jquery', 'jquery', 1);
