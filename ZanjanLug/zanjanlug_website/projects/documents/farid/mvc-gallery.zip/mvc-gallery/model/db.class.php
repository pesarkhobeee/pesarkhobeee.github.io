<?php

class db{

/*** Declare instance ***/
private static  $instance = NULL;
  		private static $host='localhost';
	private static	$user='root';
	private static	$pass='';
	private static	$database_name='gallery';
	private static	$link;

/**
*
* the constructor is set to private so
* so nobody can create a new instance using new
*
*/
private function __construct() {
  /*** maybe set the db name here later ***/
		

}

public static function getInstance() {

		
if (!self::$instance)
    {

		
   /* self::$instance = new PDO("mysql:host=localhost;dbname=gallery", 'root', '');;
    self::$instance-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);*/
	
    }
return self::$instance;
}


function query($str){
        self::$link=mysql_connect(self::$host,self::$user,self::$pass);
		mysql_select_db(self::$database_name);
if($result=mysql_query($str,self::$link))
return $result;
else
return mysql_error();
}


/**
*
* Like the constructor, we make __clone private
* so nobody can clone the instance
*
*/
private function __clone(){
}

} /*** end of class ***/

?>
