<?php

Class indexController Extends baseController {

public function index() {


//create gallery item from data base
$item='<div id="gallery"> <ul>';
		$result=db::query('SELECT * from gallery_img');
		while($row=mysql_fetch_assoc($result))
		{

$item.='     <li>
            <a href="photos/'.$row["img_url"].'" title="'.$row["img_title"].'">
                <img src="photos/'.$row["img_url"].'" width="72" height="72" alt="" />
            </a>
        </li>';
		}
$item.=' </ul>
</div>';
		
		
		
		

	/*** set a template variable ***/
        $this->registry->template->welcome = $item;
	/*** load the index template ***/
        $this->registry->template->show('index');
}

public function about() {
	/*** set a template variable ***/
        $this->registry->template->about_us = 'hi ! my name is farid :-)';
	/*** load the index template ***/
        $this->registry->template->show('about');
}

}

?>
