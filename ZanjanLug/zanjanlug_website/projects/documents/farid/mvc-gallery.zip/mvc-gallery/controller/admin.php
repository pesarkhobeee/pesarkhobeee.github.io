
<?php

Class adminController Extends baseController {

public function index() 
{

	// define all links of administrator
	$link = '<a href="admin/photos" >admin_photos</a><br><a href="admin/photosInsert" >photos_Insert</a>';


        $this->registry->template->contents = $link;
        $this->registry->template->show('admin_index');
}


public function login(){

        $this->registry->template->contents = 'This is login page';

	$this->registry->template->show('admin_login');
}


public function photos(){




	//show all of img

	$item='
		<table width="100%" border="1">
		  <tr>
		 	 <td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		  </tr>
		';


		$result=db::query('SELECT * from gallery_img inner join gallery_groups on  gallery_img.g_id= gallery_groups.g_id');
		
		
		while($row=mysql_fetch_assoc($result))
		{
		$item.="  
	<tr>
	<td><a href='photosRemover?id=$row[img_id]' >delet</a></td>
	<td><a href='photosUpdate?id=$row[img_id]' >update</a></td>
	<td><img src='../photos/$row[img_url]' alt='$row[img_alt]' height='100' width='100'  /></td>
	<td>$row[img_title]</td>
	<td>$row[g_name]</td>
	</tr>
					  ";
		}
		
		
	$item.='</table>';
		
		
		
		
			
			
			
        $this->registry->template->contents = $item;

	$this->registry->template->show('admin_photos');
	

}

public function photosRemover(){


 	$result=db::query(sprintf("DELETE FROM gallery_img WHERE img_id=%s",$_GET['id']));
	
	if($result){
		$item='<meta http-equiv="Refresh" content="0;URL=photos" />';
	}else{
		$item='sorry ! there was a problem in delet item from gallery';
	}

    $this->registry->template->contents = $item;

	$this->registry->template->show('admin_photosRemover');
}














public function photosUpdate(){

	if(isset($_POST["g_id"])){
	
	
		

			$upload_file = $_FILES["img_url"]["name"];
			$hast = true;
			
	
			while($hast){
	
				if(file_exists('photos/'.$upload_file))
				$upload_file = "1" . $upload_file;
				else
				$hast = false;
	
			}
	
	
	
	
	
	
			if (move_uploaded_file($_FILES["img_url"]["tmp_name"],'photos/'.$upload_file)){
	
	
	
	
	
		$result=db::query("UPDATE gallery_img SET img_url='".$upload_file."',img_title='".$_POST['img_title']."',img_alt='".$_POST['img_alt']."' WHERE img_id=".$_GET['id']);
					
							if($result){
							$item='<meta http-equiv="Refresh" content="0;URL=photos" />';
							}else{
								$item='sorry ! there was a problem in update item from gallery';
							}
		
					
				
				
				
				}
			else{
				echo "sorry! upload is failed";
				}
		
	


	}else{

	$item='
	<form id="insertimg" name="insertimg" method="post" action="" enctype="multipart/form-data">
	  <p align="center">
		<input name="g_id" type="hidden" id="g_id" value="1" />
	  </p>
	  <table width="100%" border="0">
		<tr>
		  <td><input type="file" name="img_url" id="img_url" /></td>
		  <td>&#1575;&#1583;&#1585;&#1587; &#1593;&#1705;&#1587;</td>
		</tr>
		<tr>
		  <td><input type="text" name="img_title" id="img_title" /></td>
		  <td>&#1593;&#1606;&#1608;&#1575;&#1606; &#1593;&#1705;&#1587;</td>
		</tr>
		<tr>
		  <td><input type="text" name="img_alt" id="img_alt" /></td>
		  <td>alt</td>
		</tr>
	  </table>
	  <p align="center">
		<label>
		<input type="submit" name="button" id="button" value="&#1579;&#1576;&#1578;" />
		</label>
	</p>
	</form>
	';


}



					   

        $this->registry->template->contents = $item;

		$this->registry->template->show('admin_photosUpdate');
}
















public function photosInsert(){



	if(isset($_POST["g_id"])){

		$upload_file = $_FILES["img_url"]["name"];
		$hast = true;
		

		while($hast){

			if(file_exists('photos/'.$upload_file))
			$upload_file = "1" . $upload_file;
			else
			$hast = false;

		}
	
	
	
	
	
	
		if (move_uploaded_file($_FILES["img_url"]["tmp_name"],'photos/'.$upload_file)){





					$result=db::query("INSERT INTO `gallery`.`gallery_img` (
					`img_id` ,
					`img_url` ,
					`img_title` ,
					`img_alt` ,
					`g_id`
					)
					VALUES (
					NULL , '".$upload_file."', '".$_POST["img_title"]."', '".$_POST["img_alt"]."',		 '1')");
					
					if($result){
						$item='<meta http-equiv="Refresh" content="0;URL=photos" />';
					}else{
						$item='sorry ! there was a problem in insert item from gallery';
					}

			
		
		
		
		}
	else{
		echo "sorry! upload is failed";
		}
		
	


}else{

	$item='
	<form id="insertimg" name="insertimg" method="post" action="" enctype="multipart/form-data">
	  <p align="center">
		<input name="g_id" type="hidden" id="g_id" value="1" />
	  </p>
	  <table width="100%" border="0">
		<tr>
		  <td><input type="file" name="img_url" id="img_url" /></td>
		  <td>&#1575;&#1583;&#1585;&#1587; &#1593;&#1705;&#1587;</td>
		</tr>
		<tr>
		  <td><input type="text" name="img_title" id="img_title" /></td>
		  <td>&#1593;&#1606;&#1608;&#1575;&#1606; &#1593;&#1705;&#1587;</td>
		</tr>
		<tr>
		  <td><input type="text" name="img_alt" id="img_alt" /></td>
		  <td>alt</td>
		</tr>
	  </table>
	  <p align="center">
		<label>
		<input type="submit" name="button" id="button" value="&#1579;&#1576;&#1578;" />
		</label>
	</p>
	</form>
	';


}

        $this->registry->template->contents =$item;

		$this->registry->template->show('admin_photosInsert');

}





}
?>
