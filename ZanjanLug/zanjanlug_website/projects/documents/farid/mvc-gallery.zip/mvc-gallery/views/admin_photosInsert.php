<h1><?php echo $contents; ?></h1>



