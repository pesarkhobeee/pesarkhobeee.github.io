#include <QtGui>
#include "hello.h"


hello::hello(QWidget *parent)
:QWidget(parent)
{ 
label = new QLabel ("Hello World!");
button = new QPushButton("Enter");
QHBoxLayout *layout = new QHBoxLayout;
layout->addWidget(label);
layout->addWidget(button);
this->setLayout(layout);
connect(button, SIGNAL(clicked()),this,SLOT(showHello()));
}
void hello::setInterface()
{
int WIDTH = 250;
int HEIGHT = 150;
int screenWidth;
int screenHeight;
int x, y;
QDesktopWidget *desktop = QApplication::desktop();
screenWidth = desktop->width();
screenHeight = desktop->height();
x = (screenWidth - WIDTH) / 2;
y = (screenHeight - HEIGHT) / 2;
this->resize(WIDTH, HEIGHT);
this->move( x, y );
this->setWindowTitle("Center");
this->setToolTip("Center window");
this->setWindowIcon(QIcon("icon.jpg"));
} 


void hello::showHello()
{
QString str = QString::fromUtf8("افتتاح سایت زنجان لاگ مبارک باد<br> www.zanjanlug.org");
label->setText(str);
}


