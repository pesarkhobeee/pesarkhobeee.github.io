#include <QtGui>
#include "hello.h"
int main(int argc, char *argv[])
{
QApplication app(argc, argv);
hello *Hello = new hello;
Hello->setInterface();
Hello->show();
return app.exec();
} 
