#ifndef hello_h
#define hello_h
#include <Qt/qwidget.h>
#include <QMainWindow>

class QLabel;
class QPushButton;
class hello : public QWidget
{
Q_OBJECT
public:
hello(QWidget *parent = 0);
void setInterface();
private:
QLabel *label;
QPushButton *button;

private slots:
void showHello();

};


#endif 
