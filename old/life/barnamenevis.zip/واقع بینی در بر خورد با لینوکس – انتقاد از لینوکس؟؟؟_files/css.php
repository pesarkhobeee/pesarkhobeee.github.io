.cke_skin_kama .cke_wrapper {
	background-color: #DEDEDE !important;
}